"""Replay a throw using seven starting joint angles in radians.

With a window: python replay.py --angles 0,0,0,0,0,0,0
Headless:      python replay.py --angles 0,0,0,0,0,0,0 --headless
Negative first angle: python replay.py --angles=-0.5,0,0,0,0,0,0
"""
import argparse
import math
import time

import pybullet as p
import pybullet_data

TIME_STEP = 1.0 / 240
SIM_STEPS = 240 * 3


def parse_angles(text):
    try:
        angles = [float(value) for value in text.split(",")]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Angles must be comma-separated numbers") from exc
    if len(angles) != 7 or not all(math.isfinite(angle) for angle in angles):
        raise argparse.ArgumentTypeError("Provide exactly seven finite angles in radians")
    return angles


def simulate_throw(joint_angles, headless=False):
    """Same initial state, motor commands, and release timing as pso.py."""
    p.resetSimulation()
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.setGravity(0, 0, -9.81)
    p.setTimeStep(TIME_STEP)
    p.setRealTimeSimulation(0)
    p.loadURDF("plane.urdf")
    arm = p.loadURDF("kuka_iiwa/model.urdf", [0, 0, 0], useFixedBase=True)
    ball = p.loadURDF("sphere2.urdf", [0, 0, 0], globalScaling=0.05)

    for joint, angle in enumerate(joint_angles):
        p.resetJointState(arm, joint, angle)

    attachment = p.createConstraint(
        arm, p.getNumJoints(arm) - 1, ball, -1,
        p.JOINT_FIXED, [0, 0, 0], [0, 0, 0], [0, 0, 0],
    )

    # Move toward starting angles + 0.2 radians for one second.
    for _ in range(SIM_STEPS // 3):
        for joint, angle in enumerate(joint_angles):
            p.setJointMotorControl2(
                arm, joint, p.POSITION_CONTROL,
                targetPosition=angle + 0.2, force=500,
            )
        p.stepSimulation()
        if not headless:
            time.sleep(TIME_STEP)

    # Release the ball, then simulate two seconds of flight.
    p.removeConstraint(attachment)
    for _ in range(SIM_STEPS * 2 // 3):
        p.stepSimulation()
        if not headless:
            time.sleep(TIME_STEP)

    position, _ = p.getBasePositionAndOrientation(ball)
    return position


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--angles", type=parse_angles, required=True,
                        help="Seven comma-separated starting joint angles in radians")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--headless", "--headles", action="store_true",
                      help="Run without a window or real-time delays")
    mode.add_argument("--headed", action="store_true", help="Open the GUI (default)")
    args = parser.parse_args()

    client = p.connect(p.DIRECT if args.headless else p.GUI)
    if client < 0:
        raise RuntimeError("Could not connect to PyBullet")
    try:
        if not args.headless:
            p.resetDebugVisualizerCamera(2.5, 45, -25, [0, 0, 0.6])
        position = simulate_throw(args.angles, args.headless)
        print(f"Final ball position: x={position[0]:.6f}, y={position[1]:.6f}, z={position[2]:.6f} m")
        print(f"Score (final world x): {position[0]:.6f} m")
        if not args.headless:
            # Leave the result visible briefly, as in arm-visualize.py.
            time.sleep(2)
    except KeyboardInterrupt:
        pass
    except p.error:
        if p.isConnected(client):
            raise
    finally:
        if p.isConnected(client):
            p.disconnect(client)


if __name__ == "__main__":
    main()
