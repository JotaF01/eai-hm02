import pybullet as p
import pybullet_data
import numpy as np
import time

TIME_STEP = 1.0 / 240
SIM_STEPS = 240 * 3  # 3 seconds

def setup_environment():
    p.resetSimulation()
    p.setGravity(0, 0, -9.81)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.loadURDF("plane.urdf")
    kuka = p.loadURDF("kuka_iiwa/model.urdf", [0,0,0], useFixedBase=True)
    sphere = p.loadURDF("sphere2.urdf", [0,0,0], globalScaling=0.05)
    return kuka, sphere

def visualize_throw(joint_angles):
    kuka, sphere = setup_environment()
    num_joints = p.getNumJoints(kuka)

    # Set initial joint states
    for i, angle in enumerate(joint_angles):
        p.resetJointState(kuka, i, angle)

    cid = p.createConstraint(
        kuka, num_joints - 1, sphere, -1,
        p.JOINT_FIXED, [0,0,0], [0,0,0], [0,0,0])

    # Simulate throw motion visually
    for step in range(SIM_STEPS // 3):
        for j in range(num_joints):
            p.setJointMotorControl2(kuka, j, p.POSITION_CONTROL,
                                    targetPosition=joint_angles[j] + 0.2,
                                    force=500)
        p.stepSimulation()
        time.sleep(TIME_STEP)

    # Release ball
    p.removeConstraint(cid)

    # Let ball fly freely
    for _ in range(SIM_STEPS * 2 // 3):
        p.stepSimulation()
        time.sleep(TIME_STEP)

    time.sleep(2)
    p.disconnect()

# Load optimized angles from CSV and visualize
optimal_angles = np.loadtxt('arm_best_angles.csv', delimiter=',')
p.connect(p.GUI)
visualize_throw(optimal_angles)
